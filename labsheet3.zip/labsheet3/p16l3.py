# Q16: Count digits, alphabets and special characters

text = input("Enter a string: ")

digits = 0
alphabets = 0
special = 0

for ch in text:

    if ch.isalpha():
        alphabets += 1

    elif ch.isdigit():
        digits += 1

    else:
        special += 1

print("Number of alphabets:", alphabets)
print("Number of digits:", digits)
print("Number of special characters:", special)
