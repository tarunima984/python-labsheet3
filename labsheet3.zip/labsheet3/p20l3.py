# Q20: Check whether two strings are rotations of each other

str1 = input("Enter first string: ")
str2 = input("Enter second string: ")

if len(str1) != len(str2):
    print("The strings are not rotations.")
else:

    combined = str1 + str1

    if str2 in combined:
        print("The strings are rotations of each other.")
    else:
        print("The strings are not rotations of each other.")
