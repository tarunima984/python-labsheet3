# Q14: Remove punctuation from a string

text = input("Enter a string: ")

result = ""

for ch in text:

    if ch.isalnum() or ch == ' ':
        result = result + ch

print("String after removing punctuation:", result)
