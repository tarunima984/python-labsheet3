# Q22: Sort a list in ascending and descending order

numbers = input("Enter numbers: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

# Ascending order
for i in range(len(numbers)):
    for j in range(i + 1, len(numbers)):
        if numbers[i] > numbers[j]:
            numbers[i], numbers[j] = numbers[j], numbers[i]

print("Ascending order:", numbers)

# Descending order
print("Descending order:", numbers[::-1])
