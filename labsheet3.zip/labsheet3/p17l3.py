# Q17: Print all substrings of a string

text = input("Enter a string: ")

print("All substrings are:")

for i in range(len(text)):
    for j in range(i + 1, len(text)):
        print(text[i:j])
