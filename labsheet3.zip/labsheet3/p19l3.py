# Q19: Find the most repeated word in a string

text = input("Enter a string: ")

words = text.split()

most_repeated = ""
highest_count = 0

for word in words:

    count = 0

    for w in words:
        if word.lower() == w.lower():
            count += 1

    if count > highest_count:
        highest_count = count
        most_repeated = word

print("Most repeated word:", most_repeated)
print("Frequency:", highest_count)
