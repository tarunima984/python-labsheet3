# Q15: Find the first non-repeated character

text = input("Enter a string: ")

found = False

for ch in text:

    count = 0

    # Count the occurrence of character
    for c in text:
        if ch == c:
            count += 1

    if count == 1:
        print("First non-repeated character:", ch)
        found = True
        break

if not found:
    print("No non-repeated character found.")
