# Q6: Find frequency of each character

text = input("Enter a string: ")

checked = ""

for ch in text:

    # Skip character if already counted
    already_checked = False

    for c in checked:
        if ch == c:
            already_checked = True
            break

    if not already_checked:
        count = 0

        # Count occurrence of character
        for c in text:
            if ch == c:
                count += 1

        print(ch, ":", count)

        checked = checked + ch
