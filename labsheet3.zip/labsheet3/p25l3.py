# Q25: Count frequency of each element in a list

numbers = input("Enter numbers separated by spaces: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

checked = []

for num in numbers:

    found = False

    for x in checked:
        if num == x:
            found = True
            break

    if not found:

        count = 0

        for x in numbers:
            if num == x:
                count += 1

        print(num, ":", count)

        checked.append(num)
