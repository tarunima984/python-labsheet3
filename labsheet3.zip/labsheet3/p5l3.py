# Q5: Remove duplicate characters from a string

text = input("Enter a string: ")

result = ""

for ch in text:
    found = False

    # Check whether character already exists
    for r in result:
        if ch == r:
            found = True
            break

    if not found:
        result = result + ch

print("String after removing duplicates:", result)
