# Q8: Convert string into title case

text = input("Enter a string: ")

result = ""
new_word = True

for ch in text:

    if ch == ' ':
        result = result + ch
        new_word = True

    else:
        if new_word:
            # Convert first character of word to uppercase
            if ch >= 'a' and ch <= 'z':
                ch = chr(ord(ch) - 32)

            new_word = False

        else:
            # Convert remaining characters to lowercase
            if ch >= 'A' and ch <= 'Z':
                ch = chr(ord(ch) + 32)

        result = result + ch

print("Title case:", result)
