# Q29: Find difference between two lists

list1 = input("Enter elements of first list: ").split()
list2 = input("Enter elements of second list: ").split()

difference = []

# Find elements present in list1 but not in list2
for item in list1:

    found = False

    for x in list2:
        if item == x:
            found = True
            break

    if not found:
        difference.append(item)

print("Difference between the lists:", difference)
