# Q7: Reverse a string without using slicing

text = input("Enter a string: ")

reverse = ""

for i in range(len(text) - 1, -1, -1):
    reverse = reverse + text[i]

print("Reversed string:", reverse)
