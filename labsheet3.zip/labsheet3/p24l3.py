# Q24: Reverse a list without using built-in functions

numbers = input("Enter numbers separated by spaces: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

reverse = []

for i in range(len(numbers) - 1, -1, -1):
    reverse.append(numbers[i])

print("Reversed list:", reverse)
