# Q10: Find the longest word in a string

text = input("Enter a string: ")

longest = ""
current = ""

for ch in text:

    if ch != ' ':
        current = current + ch

    else:
        if len(current) > len(longest):
            longest = current

        current = ""

# Check the last word
if len(current) > len(longest):
    longest = current

print("Longest word:", longest)
print("Length:", len(longest))
