# Q27: Find the second largest number in a list

numbers = input("Enter numbers separated by spaces: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

# Sort the list in ascending order
for i in range(len(numbers)):
    for j in range(0, len(numbers) - i - 1):

        if numbers[j] > numbers[j + 1]:
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp

if len(numbers) < 2:
    print("Second largest number does not exist.")
else:
    largest = numbers[-1]
    second_largest = None

    # Find a value smaller than largest
    for i in range(len(numbers) - 2, -1, -1):
        if numbers[i] != largest:
            second_largest = numbers[i]
            break

    if second_largest is None:
        print("Second largest number does not exist.")
    else:
        print("Second largest number:", second_largest)
