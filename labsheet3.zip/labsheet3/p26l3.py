# Q26: Merge two lists into one

list1 = input("Enter elements of first list: ").split()
list2 = input("Enter elements of second list: ").split()

merged = []

# Add elements of first list
for item in list1:
    merged.append(item)

# Add elements of second list
for item in list2:
    merged.append(item)

print("First list:", list1)
print("Second list:", list2)
print("Merged list:", merged)
