# Q23: Remove duplicate elements from a list

numbers = input("Enter numbers separated by spaces: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

unique = []

for num in numbers:

    found = False

    for x in unique:
        if num == x:
            found = True
            break

    if not found:
        unique.append(num)

print("List after removing duplicates:", unique)
