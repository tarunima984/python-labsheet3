# Q3: Replace all spaces with underscores

text = input("Enter a string: ")

result = ""

for ch in text:
    if ch == ' ':
        result = result + '_'
    else:
        result = result + ch

print("String after replacing spaces:", result)
