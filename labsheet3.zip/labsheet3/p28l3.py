# Q28: Find common elements in two lists

list1 = input("Enter elements of first list: ").split()
list2 = input("Enter elements of second list: ").split()

common = []

for item in list1:

    found = False

    for x in list2:
        if item == x:
            found = True
            break

    if found:

        already_added = False

        for x in common:
            if item == x:
                already_added = True
                break

        if not already_added:
            common.append(item)

print("Common elements:", common)
