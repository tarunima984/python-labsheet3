# Q13: Convert vowels to uppercase and consonants to lowercase

text = input("Enter a string: ")

result = ""

for ch in text:

    if ch.isalpha():

        if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u':
            result = result + ch.upper()

        elif ch == 'A' or ch == 'E' or ch == 'I' or ch == 'O' or ch == 'U':
            result = result + ch

        else:
            result = result + ch.lower()

    else:
        result = result + ch

print("Result:", result)
