# Q12: Check whether a substring exists in a string

text = input("Enter the main string: ")
substring = input("Enter the substring: ")

if substring in text:
    print("Substring exists in the string.")
else:
    print("Substring does not exist in the string.")
