# Q2: Count vowels and consonants

text = input("Enter a string: ")

vowels = 0
consonants = 0

for ch in text:
    if ch.isalpha():
        if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u' or \
           ch == 'A' or ch == 'E' or ch == 'I' or ch == 'O' or ch == 'U':
            vowels += 1
        else:
            consonants += 1

print("Number of vowels:", vowels)
print("Number of consonants:", consonants)
