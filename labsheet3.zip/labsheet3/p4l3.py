# Q4: Extract all uppercase characters

text = input("Enter a string: ")

result = ""

for ch in text:
    if ch >= 'A' and ch <= 'Z':
        result = result + ch

print("Uppercase characters:", result)
