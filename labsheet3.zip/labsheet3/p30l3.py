# Q30: Separate even and odd numbers from a list

numbers = input("Enter numbers separated by spaces: ").split()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

even = []
odd = []

for num in numbers:

    if num % 2 == 0:
        even.append(num)
    else:
        odd.append(num)

print("Even numbers:", even)
print("Odd numbers:", odd)
