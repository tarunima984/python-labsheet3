# Q21: Find largest and smallest element in a list

numbers = input("Enter numbers separated by spaces: ").split()

# Convert input into integers
for i in range(len(numbers)):
    numbers[i] = int(numbers[i])

largest = numbers[0]
smallest = numbers[0]

for num in numbers:
    if num > largest:
        largest = num

    if num < smallest:
        smallest = num

print("Largest element:", largest)
print("Smallest element:", smallest)
