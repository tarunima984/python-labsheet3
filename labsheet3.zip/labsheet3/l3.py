Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

======== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p1l3.py =======
Enter a string: hi i am taru i am hi
The string is not a palindrome.

======== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p1l3.py =======
Enter a string: arcrurcra
The string is a palindrome.

====== RESTART: C:/Users/hp/OneDrive/Documents/MCA/PYTHON/code/p2l3.py ======
Enter a string: hlo taru this side
Number of vowels: 6
Number of consonants: 9

============== RESTART: C:/Users/hp/OneDrive/Documents/p3l3.py ==============
Enter a string: my first priority is always me
String after replacing spaces: my_first_priority_is_always_me

============== RESTART: C:/Users/hp/OneDrive/Documents/p4l3.py ==============
Enter a string: shutup the stupid male gender
Uppercase characters: 

============== RESTART: C:/Users/hp/OneDrive/Documents/p4l3.py ==============
Enter a string:  shutup the stupid male gender
Uppercase characters: 

============== RESTART: C:/Users/hp/OneDrive/Documents/p4l3.py ==============
Enter a string: SHUTUP the stupid MALE gender
Uppercase characters: SHUTUPMALE

============== RESTART: C:/Users/hp/OneDrive/Documents/p5l3.py ==============
Enter a string: kya yaar kitna likhna pdega
String after removing duplicates: kya ritnlhpdeg

============== RESTART: C:/Users/hp/OneDrive/Documents/p6l3.py ==============
Enter a string: uff labsheets and assignments
u : 1
f : 2
  : 3
l : 1
a : 3
b : 1
s : 5
h : 1
e : 3
t : 2
n : 3
d : 1
i : 1
g : 1
m : 1

============== RESTART: C:/Users/hp/OneDrive/Documents/p7l3.py ==============
Enter a string: aaloparathe is soo tasty
Reversed string: ytsat oos si ehtarapolaa

============== RESTART: C:/Users/hp/OneDrive/Documents/p8l3.py ==============
Enter a string: the future writer tarunima
Title case: The Future Writer Tarunima

============== RESTART: C:/Users/hp/OneDrive/Documents/p9l3.py ==============
Enter a string: krle bhai krle count tu bhi
Number of words: 6

============== RESTART: C:/Users/hp/OneDrive/Documents/p10l3.py =============
Enter a string: Tarunima lokvikas goswami giri puri singh
Longest word: Tarunima
Length: 8

============== RESTART: C:/Users/hp/OneDrive/Documents/p11l3.py =============
Enter first string: i dont know what going to happen in this program
Enter second string: what going to happen
The strings are not anagrams.

============== RESTART: C:/Users/hp/OneDrive/Documents/p11l3.py =============
Enter first string: hello emme
Enter second string: meme elloh
The strings are anagrams.

============== RESTART: C:/Users/hp/OneDrive/Documents/p12l3.py =============
Enter the main string: taru diya and palak are baddies
Enter the substring: taru diya
Substring exists in the string.

============== RESTART: C:/Users/hp/OneDrive/Documents/p13l3.py =============
Enter a string: pak pak pakkak pak pak pakkak
Result: pAk pAk pAkkAk pAk pAk pAkkAk

============== RESTART: C:/Users/hp/OneDrive/Documents/p14l3.py =============
Enter a string: oyee! pagal h kya, yaar tu
String after removing punctuation: oyee pagal h kya yaar tu

============== RESTART: C:/Users/hp/OneDrive/Documents/p15l3.py =============
Enter a string: moj lo roj lo nhi mile toh khoj lo
First non-repeated character: r

============== RESTART: C:/Users/hp/OneDrive/Documents/p16l3.py =============
Enter a string: Trunima this side. my cu id is 26280002
Number of alphabets: 23
Number of digits: 8
Number of special characters: 8

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l3.py =============
Enter a string: m tarunima who is writer, poet, student, can sing and as well as drawing
All substrings are:
m
m 
m t
m ta
m tar
m taru
m tarun
m taruni
m tarunim
m tarunima
m tarunima 
m tarunima w
m tarunima wh
m tarunima who
m tarunima who 
m tarunima who i
m tarunima who is
m tarunima who is 
m tarunima who is w
m tarunima who is wr
m tarunima who is wri
m tarunima who is writ
m tarunima who is write
m tarunima who is writer
m tarunima who is writer,
m tarunima who is writer, 
m tarunima who is writer, p
m tarunima who is writer, po
m tarunima who is writer, poe
m tarunima who is writer, poet
m tarunima who is writer, poet,
m tarunima who is writer, poet, 
m tarunima who is writer, poet, s
m tarunima who is writer, poet, st
m tarunima who is writer, poet, stu
m tarunima who is writer, poet, stud
m tarunima who is writer, poet, stude
m tarunima who is writer, poet, studen
m tarunima who is writer, poet, student
m tarunima who is writer, poet, student,
m tarunima who is writer, poet, student, 
m tarunima who is writer, poet, student, c
m tarunima who is writer, poet, student, ca
m tarunima who is writer, poet, student, can
m tarunima who is writer, poet, student, can 
m tarunima who is writer, poet, student, can s
m tarunima who is writer, poet, student, can si
m tarunima who is writer, poet, student, can sin
m tarunima who is writer, poet, student, can sing
m tarunima who is writer, poet, student, can sing 
m tarunima who is writer, poet, student, can sing a
m tarunima who is writer, poet, student, can sing an
m tarunima who is writer, poet, student, can sing and
m tarunima who is writer, poet, student, can sing and 
m tarunima who is writer, poet, student, can sing and a
m tarunima who is writer, poet, student, can sing and as
m tarunima who is writer, poet, student, can sing and as 
m tarunima who is writer, poet, student, can sing and as w
m tarunima who is writer, poet, student, can sing and as we
m tarunima who is writer, poet, student, can sing and as wel
m tarunima who is writer, poet, student, can sing and as well
m tarunima who is writer, poet, student, can sing and as well 
m tarunima who is writer, poet, student, can sing and as well a
m tarunima who is writer, poet, student, can sing and as well as
m tarunima who is writer, poet, student, can sing and as well as 
m tarunima who is writer, poet, student, can sing and as well as d
m tarunima who is writer, poet, student, can sing and as well as dr
m tarunima who is writer, poet, student, can sing and as well as dra
m tarunima who is writer, poet, student, can sing and as well as draw
m tarunima who is writer, poet, student, can sing and as well as drawi
m tarunima who is writer, poet, student, can sing and as well as drawin
 
 t
 ta
 tar
 taru
 tarun
 taruni
 tarunim
 tarunima
 tarunima 
 tarunima w
 tarunima wh
 tarunima who
 tarunima who 
 tarunima who i
 tarunima who is
 tarunima who is 
 tarunima who is w
 tarunima who is wr
 tarunima who is wri
 tarunima who is writ
 tarunima who is write
 tarunima who is writer
 tarunima who is writer,
 tarunima who is writer, 
 tarunima who is writer, p
 tarunima who is writer, po
 tarunima who is writer, poe
 tarunima who is writer, poet
 tarunima who is writer, poet,
 tarunima who is writer, poet, 
 tarunima who is writer, poet, s
 tarunima who is writer, poet, st
 tarunima who is writer, poet, stu
 tarunima who is writer, poet, stud
 tarunima who is writer, poet, stude
 tarunima who is writer, poet, studen
 tarunima who is writer, poet, student
 tarunima who is writer, poet, student,
 tarunima who is writer, poet, student, 
 tarunima who is writer, poet, student, c
 tarunima who is writer, poet, student, ca
 tarunima who is writer, poet, student, can
 tarunima who is writer, poet, student, can 
 tarunima who is writer, poet, student, can s
 tarunima who is writer, poet, student, can si
 tarunima who is writer, poet, student, can sin
 tarunima who is writer, poet, student, can sing
 tarunima who is writer, poet, student, can sing 
 tarunima who is writer, poet, student, can sing a
 tarunima who is writer, poet, student, can sing an
 tarunima who is writer, poet, student, can sing and
 tarunima who is writer, poet, student, can sing and 
 tarunima who is writer, poet, student, can sing and a
 tarunima who is writer, poet, student, can sing and as
 tarunima who is writer, poet, student, can sing and as 
 tarunima who is writer, poet, student, can sing and as w
 tarunima who is writer, poet, student, can sing and as we
 tarunima who is writer, poet, student, can sing and as wel
 tarunima who is writer, poet, student, can sing and as well
 tarunima who is writer, poet, student, can sing and as well 
 tarunima who is writer, poet, student, can sing and as well a
 tarunima who is writer, poet, student, can sing and as well as
 tarunima who is writer, poet, student, can sing and as well as 
 tarunima who is writer, poet, student, can sing and as well as d
 tarunima who is writer, poet, student, can sing and as well as dr
 tarunima who is writer, poet, student, can sing and as well as dra
 tarunima who is writer, poet, student, can sing and as well as draw
 tarunima who is writer, poet, student, can sing and as well as drawi
 tarunima who is writer, poet, student, can sing and as well as drawin
t
ta
tar
taru
tarun
taruni
tarunim
tarunima
tarunima 
tarunima w
tarunima wh
tarunima who
tarunima who 
tarunima who i
tarunima who is
tarunima who is 
tarunima who is w
tarunima who is wr
tarunima who is wri
tarunima who is writ
tarunima who is write
tarunima who is writer
tarunima who is writer,
tarunima who is writer, 
tarunima who is writer, p
tarunima who is writer, po
tarunima who is writer, poe
tarunima who is writer, poet
tarunima who is writer, poet,
tarunima who is writer, poet, 
tarunima who is writer, poet, s
tarunima who is writer, poet, st
tarunima who is writer, poet, stu
tarunima who is writer, poet, stud
tarunima who is writer, poet, stude
tarunima who is writer, poet, studen
tarunima who is writer, poet, student
tarunima who is writer, poet, student,
tarunima who is writer, poet, student, 
tarunima who is writer, poet, student, c
tarunima who is writer, poet, student, ca
tarunima who is writer, poet, student, can
tarunima who is writer, poet, student, can 
tarunima who is writer, poet, student, can s
tarunima who is writer, poet, student, can si
tarunima who is writer, poet, student, can sin
tarunima who is writer, poet, student, can sing
tarunima who is writer, poet, student, can sing 
tarunima who is writer, poet, student, can sing a
tarunima who is writer, poet, student, can sing an
tarunima who is writer, poet, student, can sing and
tarunima who is writer, poet, student, can sing and 
tarunima who is writer, poet, student, can sing and a
tarunima who is writer, poet, student, can sing and as
tarunima who is writer, poet, student, can sing and as 
tarunima who is writer, poet, student, can sing and as w
tarunima who is writer, poet, student, can sing and as we
tarunima who is writer, poet, student, can sing and as wel
tarunima who is writer, poet, student, can sing and as well
tarunima who is writer, poet, student, can sing and as well 
tarunima who is writer, poet, student, can sing and as well a
tarunima who is writer, poet, student, can sing and as well as
tarunima who is writer, poet, student, can sing and as well as 
tarunima who is writer, poet, student, can sing and as well as d
tarunima who is writer, poet, student, can sing and as well as dr
tarunima who is writer, poet, student, can sing and as well as dra
tarunima who is writer, poet, student, can sing and as well as draw
tarunima who is writer, poet, student, can sing and as well as drawi
tarunima who is writer, poet, student, can sing and as well as drawin
a
ar
aru
arun
aruni
arunim
arunima
arunima 
arunima w
arunima wh
arunima who
arunima who 
arunima who i
arunima who is
arunima who is 
arunima who is w
arunima who is wr
arunima who is wri
arunima who is writ
arunima who is write
arunima who is writer
arunima who is writer,
arunima who is writer, 
arunima who is writer, p
arunima who is writer, po
arunima who is writer, poe
arunima who is writer, poet
arunima who is writer, poet,
arunima who is writer, poet, 
arunima who is writer, poet, s
arunima who is writer, poet, st
arunima who is writer, poet, stu
arunima who is writer, poet, stud
arunima who is writer, poet, stude
arunima who is writer, poet, studen
arunima who is writer, poet, student
arunima who is writer, poet, student,
arunima who is writer, poet, student, 
arunima who is writer, poet, student, c
arunima who is writer, poet, student, ca
arunima who is writer, poet, student, can
arunima who is writer, poet, student, can 
arunima who is writer, poet, student, can s
arunima who is writer, poet, student, can si
arunima who is writer, poet, student, can sin
arunima who is writer, poet, student, can sing
arunima who is writer, poet, student, can sing 
arunima who is writer, poet, student, can sing a
arunima who is writer, poet, student, can sing an
arunima who is writer, poet, student, can sing and
arunima who is writer, poet, student, can sing and 
arunima who is writer, poet, student, can sing and a
arunima who is writer, poet, student, can sing and as
arunima who is writer, poet, student, can sing and as 
arunima who is writer, poet, student, can sing and as w
arunima who is writer, poet, student, can sing and as we
arunima who is writer, poet, student, can sing and as wel
arunima who is writer, poet, student, can sing and as well
arunima who is writer, poet, student, can sing and as well 
arunima who is writer, poet, student, can sing and as well a
arunima who is writer, poet, student, can sing and as well as
arunima who is writer, poet, student, can sing and as well as 
arunima who is writer, poet, student, can sing and as well as d
arunima who is writer, poet, student, can sing and as well as dr
arunima who is writer, poet, student, can sing and as well as dra
arunima who is writer, poet, student, can sing and as well as draw
arunima who is writer, poet, student, can sing and as well as drawi
arunima who is writer, poet, student, can sing and as well as drawin
r
ru
run
runi
runim
runima
runima 
runima w
runima wh
runima who
runima who 
runima who i
runima who is
runima who is 
runima who is w
runima who is wr
runima who is wri
runima who is writ
runima who is write
runima who is writer
runima who is writer,
runima who is writer, 
runima who is writer, p
runima who is writer, po
runima who is writer, poe
runima who is writer, poet
runima who is writer, poet,
runima who is writer, poet, 
runima who is writer, poet, s
runima who is writer, poet, st
runima who is writer, poet, stu
runima who is writer, poet, stud
runima who is writer, poet, stude
runima who is writer, poet, studen
runima who is writer, poet, student
runima who is writer, poet, student,
runima who is writer, poet, student, 
runima who is writer, poet, student, c
runima who is writer, poet, student, ca
runima who is writer, poet, student, can
runima who is writer, poet, student, can 
runima who is writer, poet, student, can s
runima who is writer, poet, student, can si
runima who is writer, poet, student, can sin
runima who is writer, poet, student, can sing
runima who is writer, poet, student, can sing 
runima who is writer, poet, student, can sing a
runima who is writer, poet, student, can sing an
runima who is writer, poet, student, can sing and
runima who is writer, poet, student, can sing and 
runima who is writer, poet, student, can sing and a
runima who is writer, poet, student, can sing and as
runima who is writer, poet, student, can sing and as 
runima who is writer, poet, student, can sing and as w
runima who is writer, poet, student, can sing and as we
runima who is writer, poet, student, can sing and as wel
runima who is writer, poet, student, can sing and as well
runima who is writer, poet, student, can sing and as well 
runima who is writer, poet, student, can sing and as well a
runima who is writer, poet, student, can sing and as well as
runima who is writer, poet, student, can sing and as well as 
runima who is writer, poet, student, can sing and as well as d
runima who is writer, poet, student, can sing and as well as dr
runima who is writer, poet, student, can sing and as well as dra
runima who is writer, poet, student, can sing and as well as draw
runima who is writer, poet, student, can sing and as well as drawi
runima who is writer, poet, student, can sing and as well as drawin
u
un
uni
unim
unima
unima 
unima w
unima wh
unima who
unima who 
unima who i
unima who is
unima who is 
unima who is w
unima who is wr
unima who is wri
unima who is writ
unima who is write
unima who is writer
unima who is writer,
unima who is writer, 
unima who is writer, p
unima who is writer, po
unima who is writer, poe
unima who is writer, poet
unima who is writer, poet,
unima who is writer, poet, 
unima who is writer, poet, s
unima who is writer, poet, st
unima who is writer, poet, stu
unima who is writer, poet, stud
unima who is writer, poet, stude
unima who is writer, poet, studen
unima who is writer, poet, student
unima who is writer, poet, student,
unima who is writer, poet, student, 
unima who is writer, poet, student, c
unima who is writer, poet, student, ca
unima who is writer, poet, student, can
unima who is writer, poet, student, can 
unima who is writer, poet, student, can s
unima who is writer, poet, student, can si
unima who is writer, poet, student, can sin
unima who is writer, poet, student, can sing
unima who is writer, poet, student, can sing 
unima who is writer, poet, student, can sing a
unima who is writer, poet, student, can sing an
unima who is writer, poet, student, can sing and
unima who is writer, poet, student, can sing and 
unima who is writer, poet, student, can sing and a
unima who is writer, poet, student, can sing and as
unima who is writer, poet, student, can sing and as 
unima who is writer, poet, student, can sing and as w
unima who is writer, poet, student, can sing and as we
unima who is writer, poet, student, can sing and as wel
unima who is writer, poet, student, can sing and as well
unima who is writer, poet, student, can sing and as well 
unima who is writer, poet, student, can sing and as well a
unima who is writer, poet, student, can sing and as well as
unima who is writer, poet, student, can sing and as well as 
unima who is writer, poet, student, can sing and as well as d
unima who is writer, poet, student, can sing and as well as dr
unima who is writer, poet, student, can sing and as well as dra
unima who is writer, poet, student, can sing and as well as draw
unima who is writer, poet, student, can sing and as well as drawi
unima who is writer, poet, student, can sing and as well as drawin
n
ni
nim
nima
nima 
nima w
nima wh
nima who
nima who 
nima who i
nima who is
nima who is 
nima who is w
nima who is wr
nima who is wri
nima who is writ
nima who is write
nima who is writer
nima who is writer,
nima who is writer, 
nima who is writer, p
nima who is writer, po
nima who is writer, poe
nima who is writer, poet
nima who is writer, poet,
nima who is writer, poet, 
nima who is writer, poet, s
nima who is writer, poet, st
nima who is writer, poet, stu
nima who is writer, poet, stud
nima who is writer, poet, stude
nima who is writer, poet, studen
nima who is writer, poet, student
nima who is writer, poet, student,
nima who is writer, poet, student, 
nima who is writer, poet, student, c
nima who is writer, poet, student, ca
nima who is writer, poet, student, can
nima who is writer, poet, student, can 
nima who is writer, poet, student, can s
nima who is writer, poet, student, can si
nima who is writer, poet, student, can sin
nima who is writer, poet, student, can sing
nima who is writer, poet, student, can sing 
nima who is writer, poet, student, can sing a
nima who is writer, poet, student, can sing an
nima who is writer, poet, student, can sing and
nima who is writer, poet, student, can sing and 
nima who is writer, poet, student, can sing and a
nima who is writer, poet, student, can sing and as
nima who is writer, poet, student, can sing and as 
nima who is writer, poet, student, can sing and as w
nima who is writer, poet, student, can sing and as we
nima who is writer, poet, student, can sing and as wel
nima who is writer, poet, student, can sing and as well
nima who is writer, poet, student, can sing and as well 
nima who is writer, poet, student, can sing and as well a
nima who is writer, poet, student, can sing and as well as
nima who is writer, poet, student, can sing and as well as 
nima who is writer, poet, student, can sing and as well as d
nima who is writer, poet, student, can sing and as well as dr
nima who is writer, poet, student, can sing and as well as dra
nima who is writer, poet, student, can sing and as well as draw
nima who is writer, poet, student, can sing and as well as drawi
nima who is writer, poet, student, can sing and as well as drawin
i
im
ima
ima 
ima w
ima wh
ima who
ima who 
ima who i
ima who is
ima who is 
ima who is w
ima who is wr
ima who is wri
ima who is writ
ima who is write
ima who is writer
ima who is writer,
ima who is writer, 
ima who is writer, p
ima who is writer, po
ima who is writer, poe
ima who is writer, poet
ima who is writer, poet,
ima who is writer, poet, 
ima who is writer, poet, s
ima who is writer, poet, st
ima who is writer, poet, stu
ima who is writer, poet, stud
ima who is writer, poet, stude
ima who is writer, poet, studen
ima who is writer, poet, student
ima who is writer, poet, student,
ima who is writer, poet, student, 
ima who is writer, poet, student, c
ima who is writer, poet, student, ca
ima who is writer, poet, student, can
ima who is writer, poet, student, can 
ima who is writer, poet, student, can s
ima who is writer, poet, student, can si
ima who is writer, poet, student, can sin
ima who is writer, poet, student, can sing
ima who is writer, poet, student, can sing 
ima who is writer, poet, student, can sing a
ima who is writer, poet, student, can sing an
ima who is writer, poet, student, can sing and
ima who is writer, poet, student, can sing and 
ima who is writer, poet, student, can sing and a
ima who is writer, poet, student, can sing and as
ima who is writer, poet, student, can sing and as 
ima who is writer, poet, student, can sing and as w
ima who is writer, poet, student, can sing and as we
ima who is writer, poet, student, can sing and as wel
ima who is writer, poet, student, can sing and as well
ima who is writer, poet, student, can sing and as well 
ima who is writer, poet, student, can sing and as well a
ima who is writer, poet, student, can sing and as well as
ima who is writer, poet, student, can sing and as well as 
ima who is writer, poet, student, can sing and as well as d
ima who is writer, poet, student, can sing and as well as dr
ima who is writer, poet, student, can sing and as well as dra
ima who is writer, poet, student, can sing and as well as draw
ima who is writer, poet, student, can sing and as well as drawi
ima who is writer, poet, student, can sing and as well as drawin
m
ma
ma 
ma w
ma wh
ma who
ma who 
ma who i
ma who is
ma who is 
ma who is w
ma who is wr
ma who is wri
ma who is writ
ma who is write
ma who is writer
ma who is writer,
ma who is writer, 
ma who is writer, p
ma who is writer, po
ma who is writer, poe
ma who is writer, poet
ma who is writer, poet,
ma who is writer, poet, 
ma who is writer, poet, s
ma who is writer, poet, st
ma who is writer, poet, stu
ma who is writer, poet, stud
ma who is writer, poet, stude
ma who is writer, poet, studen
ma who is writer, poet, student
ma who is writer, poet, student,
ma who is writer, poet, student, 
ma who is writer, poet, student, c
ma who is writer, poet, student, ca
ma who is writer, poet, student, can
ma who is writer, poet, student, can 
ma who is writer, poet, student, can s
ma who is writer, poet, student, can si
ma who is writer, poet, student, can sin
ma who is writer, poet, student, can sing
ma who is writer, poet, student, can sing 
ma who is writer, poet, student, can sing a
ma who is writer, poet, student, can sing an
ma who is writer, poet, student, can sing and
ma who is writer, poet, student, can sing and 
ma who is writer, poet, student, can sing and a
ma who is writer, poet, student, can sing and as
ma who is writer, poet, student, can sing and as 
ma who is writer, poet, student, can sing and as w
ma who is writer, poet, student, can sing and as we
ma who is writer, poet, student, can sing and as wel
ma who is writer, poet, student, can sing and as well
ma who is writer, poet, student, can sing and as well 
ma who is writer, poet, student, can sing and as well a
ma who is writer, poet, student, can sing and as well as
ma who is writer, poet, student, can sing and as well as 
ma who is writer, poet, student, can sing and as well as d
ma who is writer, poet, student, can sing and as well as dr
ma who is writer, poet, student, can sing and as well as dra
ma who is writer, poet, student, can sing and as well as draw
ma who is writer, poet, student, can sing and as well as drawi
ma who is writer, poet, student, can sing and as well as drawin
a
a 
a w
a wh
a who
a who 
a who i
a who is
a who is 
a who is w
a who is wr
a who is wri
a who is writ
a who is write
a who is writer
a who is writer,
a who is writer, 
a who is writer, p
a who is writer, po
a who is writer, poe
a who is writer, poet
a who is writer, poet,
a who is writer, poet, 
a who is writer, poet, s
a who is writer, poet, st
a who is writer, poet, stu
a who is writer, poet, stud
a who is writer, poet, stude
a who is writer, poet, studen
a who is writer, poet, student
a who is writer, poet, student,
a who is writer, poet, student, 
a who is writer, poet, student, c
a who is writer, poet, student, ca
a who is writer, poet, student, can
a who is writer, poet, student, can 
a who is writer, poet, student, can s
a who is writer, poet, student, can si
a who is writer, poet, student, can sin
a who is writer, poet, student, can sing
a who is writer, poet, student, can sing 
a who is writer, poet, student, can sing a
a who is writer, poet, student, can sing an
a who is writer, poet, student, can sing and
a who is writer, poet, student, can sing and 
a who is writer, poet, student, can sing and a
a who is writer, poet, student, can sing and as
a who is writer, poet, student, can sing and as 
a who is writer, poet, student, can sing and as w
a who is writer, poet, student, can sing and as we
a who is writer, poet, student, can sing and as wel
a who is writer, poet, student, can sing and as well
a who is writer, poet, student, can sing and as well 
a who is writer, poet, student, can sing and as well a
a who is writer, poet, student, can sing and as well as
a who is writer, poet, student, can sing and as well as 
a who is writer, poet, student, can sing and as well as d
a who is writer, poet, student, can sing and as well as dr
a who is writer, poet, student, can sing and as well as dra
a who is writer, poet, student, can sing and as well as draw
a who is writer, poet, student, can sing and as well as drawi
a who is writer, poet, student, can sing and as well as drawin
 
 w
 wh
 who
 who 
 who i
 who is
 who is 
 who is w
 who is wr
 who is wri
 who is writ
 who is write
 who is writer
 who is writer,
 who is writer, 
 who is writer, p
 who is writer, po
 who is writer, poe
 who is writer, poet
 who is writer, poet,
 who is writer, poet, 
 who is writer, poet, s
 who is writer, poet, st
 who is writer, poet, stu
 who is writer, poet, stud
 who is writer, poet, stude
 who is writer, poet, studen
 who is writer, poet, student
 who is writer, poet, student,
 who is writer, poet, student, 
 who is writer, poet, student, c
 who is writer, poet, student, ca
 who is writer, poet, student, can
 who is writer, poet, student, can 
 who is writer, poet, student, can s
 who is writer, poet, student, can si
 who is writer, poet, student, can sin
 who is writer, poet, student, can sing
 who is writer, poet, student, can sing 
 who is writer, poet, student, can sing a
 who is writer, poet, student, can sing an
 who is writer, poet, student, can sing and
 who is writer, poet, student, can sing and 
 who is writer, poet, student, can sing and a
 who is writer, poet, student, can sing and as
 who is writer, poet, student, can sing and as 
 who is writer, poet, student, can sing and as w
 who is writer, poet, student, can sing and as we
 who is writer, poet, student, can sing and as wel
 who is writer, poet, student, can sing and as well
 who is writer, poet, student, can sing and as well 
 who is writer, poet, student, can sing and as well a
 who is writer, poet, student, can sing and as well as
 who is writer, poet, student, can sing and as well as 
 who is writer, poet, student, can sing and as well as d
 who is writer, poet, student, can sing and as well as dr
 who is writer, poet, student, can sing and as well as dra
 who is writer, poet, student, can sing and as well as draw
 who is writer, poet, student, can sing and as well as drawi
 who is writer, poet, student, can sing and as well as drawin
w
wh
who
who 
who i
who is
who is 
who is w
who is wr
who is wri
who is writ
who is write
who is writer
who is writer,
who is writer, 
who is writer, p
who is writer, po
who is writer, poe
who is writer, poet
who is writer, poet,
who is writer, poet, 
who is writer, poet, s
who is writer, poet, st
who is writer, poet, stu
who is writer, poet, stud
who is writer, poet, stude
who is writer, poet, studen
who is writer, poet, student
who is writer, poet, student,
who is writer, poet, student, 
who is writer, poet, student, c
who is writer, poet, student, ca
who is writer, poet, student, can
who is writer, poet, student, can 
who is writer, poet, student, can s
who is writer, poet, student, can si
who is writer, poet, student, can sin
who is writer, poet, student, can sing
who is writer, poet, student, can sing 
who is writer, poet, student, can sing a
who is writer, poet, student, can sing an
who is writer, poet, student, can sing and
who is writer, poet, student, can sing and 
who is writer, poet, student, can sing and a
who is writer, poet, student, can sing and as
who is writer, poet, student, can sing and as 
who is writer, poet, student, can sing and as w
who is writer, poet, student, can sing and as we
who is writer, poet, student, can sing and as wel
who is writer, poet, student, can sing and as well
who is writer, poet, student, can sing and as well 
who is writer, poet, student, can sing and as well a
who is writer, poet, student, can sing and as well as
who is writer, poet, student, can sing and as well as 
who is writer, poet, student, can sing and as well as d
who is writer, poet, student, can sing and as well as dr
who is writer, poet, student, can sing and as well as dra
who is writer, poet, student, can sing and as well as draw
who is writer, poet, student, can sing and as well as drawi
who is writer, poet, student, can sing and as well as drawin
h
ho
ho 
ho i
ho is
ho is 
ho is w
ho is wr
ho is wri
ho is writ
ho is write
ho is writer
ho is writer,
ho is writer, 
ho is writer, p
ho is writer, po
ho is writer, poe
ho is writer, poet
ho is writer, poet,
ho is writer, poet, 
ho is writer, poet, s
ho is writer, poet, st
ho is writer, poet, stu
ho is writer, poet, stud
ho is writer, poet, stude
ho is writer, poet, studen
ho is writer, poet, student
ho is writer, poet, student,
ho is writer, poet, student, 
ho is writer, poet, student, c
ho is writer, poet, student, ca
ho is writer, poet, student, can
ho is writer, poet, student, can 
ho is writer, poet, student, can s
ho is writer, poet, student, can si
ho is writer, poet, student, can sin
ho is writer, poet, student, can sing
ho is writer, poet, student, can sing 
ho is writer, poet, student, can sing a
ho is writer, poet, student, can sing an
ho is writer, poet, student, can sing and
ho is writer, poet, student, can sing and 
ho is writer, poet, student, can sing and a
ho is writer, poet, student, can sing and as
ho is writer, poet, student, can sing and as 
ho is writer, poet, student, can sing and as w
ho is writer, poet, student, can sing and as we
ho is writer, poet, student, can sing and as wel
ho is writer, poet, student, can sing and as well
ho is writer, poet, student, can sing and as well 
ho is writer, poet, student, can sing and as well a
ho is writer, poet, student, can sing and as well as
ho is writer, poet, student, can sing and as well as 
ho is writer, poet, student, can sing and as well as d
ho is writer, poet, student, can sing and as well as dr
ho is writer, poet, student, can sing and as well as dra
ho is writer, poet, student, can sing and as well as draw
ho is writer, poet, student, can sing and as well as drawi
ho is writer, poet, student, can sing and as well as drawin
o
o 
o i
o is
o is 
o is w
o is wr
o is wri
o is writ
o is write
o is writer
o is writer,
o is writer, 
o is writer, p
o is writer, po
o is writer, poe
o is writer, poet
o is writer, poet,
o is writer, poet, 
o is writer, poet, s
o is writer, poet, st
o is writer, poet, stu
o is writer, poet, stud
o is writer, poet, stude
o is writer, poet, studen
o is writer, poet, student
o is writer, poet, student,
o is writer, poet, student, 
o is writer, poet, student, c
o is writer, poet, student, ca
o is writer, poet, student, can
o is writer, poet, student, can 
o is writer, poet, student, can s
o is writer, poet, student, can si
o is writer, poet, student, can sin
o is writer, poet, student, can sing
o is writer, poet, student, can sing 
o is writer, poet, student, can sing a
o is writer, poet, student, can sing an
o is writer, poet, student, can sing and
o is writer, poet, student, can sing and 
o is writer, poet, student, can sing and a
o is writer, poet, student, can sing and as
o is writer, poet, student, can sing and as 
o is writer, poet, student, can sing and as w
o is writer, poet, student, can sing and as we
o is writer, poet, student, can sing and as wel
o is writer, poet, student, can sing and as well
o is writer, poet, student, can sing and as well 
o is writer, poet, student, can sing and as well a
o is writer, poet, student, can sing and as well as
o is writer, poet, student, can sing and as well as 
o is writer, poet, student, can sing and as well as d
o is writer, poet, student, can sing and as well as dr
o is writer, poet, student, can sing and as well as dra
o is writer, poet, student, can sing and as well as draw
o is writer, poet, student, can sing and as well as drawi
o is writer, poet, student, can sing and as well as drawin
 
 i
 is
 is 
 is w
 is wr
 is wri
 is writ
 is write
 is writer
 is writer,
 is writer, 
 is writer, p
 is writer, po
 is writer, poe
 is writer, poet
 is writer, poet,
 is writer, poet, 
 is writer, poet, s
 is writer, poet, st
 is writer, poet, stu
 is writer, poet, stud
 is writer, poet, stude
 is writer, poet, studen
 is writer, poet, student
 is writer, poet, student,
 is writer, poet, student, 
 is writer, poet, student, c
 is writer, poet, student, ca
 is writer, poet, student, can
 is writer, poet, student, can 
 is writer, poet, student, can s
 is writer, poet, student, can si
 is writer, poet, student, can sin
 is writer, poet, student, can sing
 is writer, poet, student, can sing 
 is writer, poet, student, can sing a
 is writer, poet, student, can sing an
 is writer, poet, student, can sing and
 is writer, poet, student, can sing and 
 is writer, poet, student, can sing and a
 is writer, poet, student, can sing and as
 is writer, poet, student, can sing and as 
 is writer, poet, student, can sing and as w
 is writer, poet, student, can sing and as we
 is writer, poet, student, can sing and as wel
 is writer, poet, student, can sing and as well
 is writer, poet, student, can sing and as well 
 is writer, poet, student, can sing and as well a
 is writer, poet, student, can sing and as well as
 is writer, poet, student, can sing and as well as 
 is writer, poet, student, can sing and as well as d
 is writer, poet, student, can sing and as well as dr
 is writer, poet, student, can sing and as well as dra
 is writer, poet, student, can sing and as well as draw
 is writer, poet, student, can sing and as well as drawi
 is writer, poet, student, can sing and as well as drawin
i
is
is 
is w
is wr
is wri
is writ
is write
is writer
is writer,
is writer, 
is writer, p
is writer, po
is writer, poe
is writer, poet
is writer, poet,
is writer, poet, 
is writer, poet, s
is writer, poet, st
is writer, poet, stu
is writer, poet, stud
is writer, poet, stude
is writer, poet, studen
is writer, poet, student
is writer, poet, student,
is writer, poet, student, 
is writer, poet, student, c
is writer, poet, student, ca
is writer, poet, student, can
is writer, poet, student, can 
is writer, poet, student, can s
is writer, poet, student, can si
is writer, poet, student, can sin
is writer, poet, student, can sing
is writer, poet, student, can sing 
is writer, poet, student, can sing a
is writer, poet, student, can sing an
is writer, poet, student, can sing and
is writer, poet, student, can sing and 
is writer, poet, student, can sing and a
is writer, poet, student, can sing and as
is writer, poet, student, can sing and as 
is writer, poet, student, can sing and as w
is writer, poet, student, can sing and as we
is writer, poet, student, can sing and as wel
is writer, poet, student, can sing and as well
is writer, poet, student, can sing and as well 
is writer, poet, student, can sing and as well a
is writer, poet, student, can sing and as well as
is writer, poet, student, can sing and as well as 
is writer, poet, student, can sing and as well as d
is writer, poet, student, can sing and as well as dr
is writer, poet, student, can sing and as well as dra
is writer, poet, student, can sing and as well as draw
is writer, poet, student, can sing and as well as drawi
is writer, poet, student, can sing and as well as drawin
s
s 
s w
s wr
s wri
s writ
s write
s writer
s writer,
s writer, 
s writer, p
s writer, po
s writer, poe
s writer, poet
s writer, poet,
s writer, poet, 
s writer, poet, s
s writer, poet, st
s writer, poet, stu
s writer, poet, stud
s writer, poet, stude
s writer, poet, studen
s writer, poet, student
s writer, poet, student,
s writer, poet, student, 
s writer, poet, student, c
s writer, poet, student, ca
s writer, poet, student, can
s writer, poet, student, can 
s writer, poet, student, can s
s writer, poet, student, can si
s writer, poet, student, can sin
s writer, poet, student, can sing
s writer, poet, student, can sing 
s writer, poet, student, can sing a
s writer, poet, student, can sing an
s writer, poet, student, can sing and
s writer, poet, student, can sing and 
s writer, poet, student, can sing and a
s writer, poet, student, can sing and as
s writer, poet, student, can sing and as 
s writer, poet, student, can sing and as w
s writer, poet, student, can sing and as we
s writer, poet, student, can sing and as wel
s writer, poet, student, can sing and as well
s writer, poet, student, can sing and as well 
s writer, poet, student, can sing and as well a
s writer, poet, student, can sing and as well as
s writer, poet, student, can sing and as well as 
s writer, poet, student, can sing and as well as d
s writer, poet, student, can sing and as well as dr
s writer, poet, student, can sing and as well as dra
s writer, poet, student, can sing and as well as draw
s writer, poet, student, can sing and as well as drawi
s writer, poet, student, can sing and as well as drawin
 
 w
 wr
 wri
 writ
 write
 writer
 writer,
 writer, 
 writer, p
 writer, po
 writer, poe
 writer, poet
 writer, poet,
 writer, poet, 
 writer, poet, s
 writer, poet, st
 writer, poet, stu
 writer, poet, stud
 writer, poet, stude
 writer, poet, studen
 writer, poet, student
 writer, poet, student,
 writer, poet, student, 
 writer, poet, student, c
 writer, poet, student, ca
 writer, poet, student, can
 writer, poet, student, can 
 writer, poet, student, can s
 writer, poet, student, can si
 writer, poet, student, can sin
 writer, poet, student, can sing
 writer, poet, student, can sing 
 writer, poet, student, can sing a
 writer, poet, student, can sing an
 writer, poet, student, can sing and
 writer, poet, student, can sing and 
 writer, poet, student, can sing and a
 writer, poet, student, can sing and as
 writer, poet, student, can sing and as 
 writer, poet, student, can sing and as w
 writer, poet, student, can sing and as we
 writer, poet, student, can sing and as wel
 writer, poet, student, can sing and as well
 writer, poet, student, can sing and as well 
 writer, poet, student, can sing and as well a
 writer, poet, student, can sing and as well as
 writer, poet, student, can sing and as well as 
 writer, poet, student, can sing and as well as d
 writer, poet, student, can sing and as well as dr
 writer, poet, student, can sing and as well as dra
 writer, poet, student, can sing and as well as draw
 writer, poet, student, can sing and as well as drawi
 writer, poet, student, can sing and as well as drawin
w
wr
wri
writ
write
writer
writer,
writer, 
writer, p
writer, po
writer, poe
writer, poet
writer, poet,
writer, poet, 
writer, poet, s
writer, poet, st
writer, poet, stu
writer, poet, stud
writer, poet, stude
writer, poet, studen
writer, poet, student
writer, poet, student,
writer, poet, student, 
writer, poet, student, c
writer, poet, student, ca
writer, poet, student, can
writer, poet, student, can 
writer, poet, student, can s
writer, poet, student, can si
writer, poet, student, can sin
writer, poet, student, can sing
writer, poet, student, can sing 
writer, poet, student, can sing a
writer, poet, student, can sing an
writer, poet, student, can sing and
writer, poet, student, can sing and 
writer, poet, student, can sing and a
writer, poet, student, can sing and as
writer, poet, student, can sing and as 
writer, poet, student, can sing and as w
writer, poet, student, can sing and as we
writer, poet, student, can sing and as wel
writer, poet, student, can sing and as well
writer, poet, student, can sing and as well 
writer, poet, student, can sing and as well a
writer, poet, student, can sing and as well as
writer, poet, student, can sing and as well as 
writer, poet, student, can sing and as well as d
writer, poet, student, can sing and as well as dr
writer, poet, student, can sing and as well as dra
writer, poet, student, can sing and as well as draw
writer, poet, student, can sing and as well as drawi
writer, poet, student, can sing and as well as drawin
r
ri
rit
rite
riter
riter,
riter, 
riter, p
riter, po
riter, poe
riter, poet
riter, poet,
riter, poet, 
riter, poet, s
riter, poet, st
riter, poet, stu
riter, poet, stud
riter, poet, stude
riter, poet, studen
riter, poet, student
riter, poet, student,
riter, poet, student, 
riter, poet, student, c
riter, poet, student, ca
riter, poet, student, can
riter, poet, student, can 
riter, poet, student, can s
riter, poet, student, can si
riter, poet, student, can sin
riter, poet, student, can sing
riter, poet, student, can sing 
riter, poet, student, can sing a
riter, poet, student, can sing an
riter, poet, student, can sing and
riter, poet, student, can sing and 
riter, poet, student, can sing and a
riter, poet, student, can sing and as
riter, poet, student, can sing and as 
riter, poet, student, can sing and as w
riter, poet, student, can sing and as we
riter, poet, student, can sing and as wel
riter, poet, student, can sing and as well
riter, poet, student, can sing and as well 
riter, poet, student, can sing and as well a
riter, poet, student, can sing and as well as
riter, poet, student, can sing and as well as 
riter, poet, student, can sing and as well as d
riter, poet, student, can sing and as well as dr
riter, poet, student, can sing and as well as dra
riter, poet, student, can sing and as well as draw
riter, poet, student, can sing and as well as drawi
riter, poet, student, can sing and as well as drawin
i
it
ite
iter
iter,
iter, 
iter, p
iter, po
iter, poe
iter, poet
iter, poet,
iter, poet, 
iter, poet, s
iter, poet, st
iter, poet, stu
iter, poet, stud
iter, poet, stude
iter, poet, studen
iter, poet, student
iter, poet, student,
iter, poet, student, 
iter, poet, student, c
iter, poet, student, ca
iter, poet, student, can
iter, poet, student, can 
iter, poet, student, can s
iter, poet, student, can si
iter, poet, student, can sin
iter, poet, student, can sing
iter, poet, student, can sing 
iter, poet, student, can sing a
iter, poet, student, can sing an
iter, poet, student, can sing and
iter, poet, student, can sing and 
iter, poet, student, can sing and a
iter, poet, student, can sing and as
iter, poet, student, can sing and as 
iter, poet, student, can sing and as w
iter, poet, student, can sing and as we
iter, poet, student, can sing and as wel
iter, poet, student, can sing and as well
iter, poet, student, can sing and as well 
iter, poet, student, can sing and as well a
iter, poet, student, can sing and as well as
iter, poet, student, can sing and as well as 
iter, poet, student, can sing and as well as d
iter, poet, student, can sing and as well as dr
iter, poet, student, can sing and as well as dra
iter, poet, student, can sing and as well as draw
iter, poet, student, can sing and as well as drawi
iter, poet, student, can sing and as well as drawin
t
te
ter
ter,
ter, 
ter, p
ter, po
ter, poe
ter, poet
ter, poet,
ter, poet, 
ter, poet, s
ter, poet, st
ter, poet, stu
ter, poet, stud
ter, poet, stude
ter, poet, studen
ter, poet, student
ter, poet, student,
ter, poet, student, 
ter, poet, student, c
ter, poet, student, ca
ter, poet, student, can
ter, poet, student, can 
ter, poet, student, can s
ter, poet, student, can si
ter, poet, student, can sin
ter, poet, student, can sing
ter, poet, student, can sing 
ter, poet, student, can sing a
ter, poet, student, can sing an
ter, poet, student, can sing and
ter, poet, student, can sing and 
ter, poet, student, can sing and a
ter, poet, student, can sing and as
ter, poet, student, can sing and as 
ter, poet, student, can sing and as w
ter, poet, student, can sing and as we
ter, poet, student, can sing and as wel
ter, poet, student, can sing and as well
ter, poet, student, can sing and as well 
ter, poet, student, can sing and as well a
ter, poet, student, can sing and as well as
ter, poet, student, can sing and as well as 
ter, poet, student, can sing and as well as d
ter, poet, student, can sing and as well as dr
ter, poet, student, can sing and as well as dra
ter, poet, student, can sing and as well as draw
ter, poet, student, can sing and as well as drawi
ter, poet, student, can sing and as well as drawin
e
er
er,
er, 
er, p
er, po
er, poe
er, poet
er, poet,
er, poet, 
er, poet, s
er, poet, st
er, poet, stu
er, poet, stud
er, poet, stude
er, poet, studen
er, poet, student
er, poet, student,
er, poet, student, 
er, poet, student, c
er, poet, student, ca
er, poet, student, can
er, poet, student, can 
er, poet, student, can s
er, poet, student, can si
er, poet, student, can sin
er, poet, student, can sing
er, poet, student, can sing 
er, poet, student, can sing a
er, poet, student, can sing an
er, poet, student, can sing and
er, poet, student, can sing and 
er, poet, student, can sing and a
er, poet, student, can sing and as
er, poet, student, can sing and as 
er, poet, student, can sing and as w
er, poet, student, can sing and as we
er, poet, student, can sing and as wel
er, poet, student, can sing and as well
er, poet, student, can sing and as well 
er, poet, student, can sing and as well a
er, poet, student, can sing and as well as
er, poet, student, can sing and as well as 
er, poet, student, can sing and as well as d
er, poet, student, can sing and as well as dr
er, poet, student, can sing and as well as dra
er, poet, student, can sing and as well as draw
er, poet, student, can sing and as well as drawi
er, poet, student, can sing and as well as drawin
r
r,
r, 
r, p
r, po
r, poe
r, poet
r, poet,
r, poet, 
r, poet, s
r, poet, st
r, poet, stu
r, poet, stud
r, poet, stude
r, poet, studen
r, poet, student
r, poet, student,
r, poet, student, 
r, poet, student, c
r, poet, student, ca
r, poet, student, can
r, poet, student, can 
r, poet, student, can s
r, poet, student, can si
r, poet, student, can sin
r, poet, student, can sing
r, poet, student, can sing 
r, poet, student, can sing a
r, poet, student, can sing an
r, poet, student, can sing and
r, poet, student, can sing and 
r, poet, student, can sing and a
r, poet, student, can sing and as
r, poet, student, can sing and as 
r, poet, student, can sing and as w
r, poet, student, can sing and as we
r, poet, student, can sing and as wel
r, poet, student, can sing and as well
r, poet, student, can sing and as well 
r, poet, student, can sing and as well a
r, poet, student, can sing and as well as
r, poet, student, can sing and as well as 
r, poet, student, can sing and as well as d
r, poet, student, can sing and as well as dr
r, poet, student, can sing and as well as dra
r, poet, student, can sing and as well as draw
r, poet, student, can sing and as well as drawi
r, poet, student, can sing and as well as drawin
,
, 
, p
, po
, poe
, poet
, poet,
, poet, 
, poet, s
, poet, st
, poet, stu
, poet, stud
, poet, stude
, poet, studen
, poet, student
, poet, student,
, poet, student, 
, poet, student, c
, poet, student, ca
, poet, student, can
, poet, student, can 
, poet, student, can s
, poet, student, can si
, poet, student, can sin
, poet, student, can sing
, poet, student, can sing 
, poet, student, can sing a
, poet, student, can sing an
, poet, student, can sing and
, poet, student, can sing and 
, poet, student, can sing and a
, poet, student, can sing and as
, poet, student, can sing and as 
, poet, student, can sing and as w
, poet, student, can sing and as we
, poet, student, can sing and as wel
, poet, student, can sing and as well
, poet, student, can sing and as well 
, poet, student, can sing and as well a
, poet, student, can sing and as well as
, poet, student, can sing and as well as 
, poet, student, can sing and as well as d
, poet, student, can sing and as well as dr
, poet, student, can sing and as well as dra
, poet, student, can sing and as well as draw
, poet, student, can sing and as well as drawi
, poet, student, can sing and as well as drawin
 
 p
 po
 poe
 poet
 poet,
 poet, 
 poet, s
 poet, st
 poet, stu
 poet, stud
 poet, stude
 poet, studen
 poet, student
 poet, student,
 poet, student, 
 poet, student, c
 poet, student, ca
 poet, student, can
 poet, student, can 
 poet, student, can s
 poet, student, can si
 poet, student, can sin
 poet, student, can sing
 poet, student, can sing 
 poet, student, can sing a
 poet, student, can sing an
 poet, student, can sing and
 poet, student, can sing and 
 poet, student, can sing and a
 poet, student, can sing and as
 poet, student, can sing and as 
 poet, student, can sing and as w
 poet, student, can sing and as we
 poet, student, can sing and as wel
 poet, student, can sing and as well
 poet, student, can sing and as well 
 poet, student, can sing and as well a
 poet, student, can sing and as well as
 poet, student, can sing and as well as 
 poet, student, can sing and as well as d
 poet, student, can sing and as well as dr
 poet, student, can sing and as well as dra
 poet, student, can sing and as well as draw
 poet, student, can sing and as well as drawi
 poet, student, can sing and as well as drawin
p
po
poe
poet
poet,
poet, 
poet, s
poet, st
poet, stu
poet, stud
poet, stude
poet, studen
poet, student
poet, student,
poet, student, 
poet, student, c
poet, student, ca
poet, student, can
poet, student, can 
poet, student, can s
poet, student, can si
poet, student, can sin
poet, student, can sing
poet, student, can sing 
poet, student, can sing a
poet, student, can sing an
poet, student, can sing and
poet, student, can sing and 
poet, student, can sing and a
poet, student, can sing and as
poet, student, can sing and as 
poet, student, can sing and as w
poet, student, can sing and as we
poet, student, can sing and as wel
poet, student, can sing and as well
poet, student, can sing and as well 
poet, student, can sing and as well a
poet, student, can sing and as well as
poet, student, can sing and as well as 
poet, student, can sing and as well as d
poet, student, can sing and as well as dr
poet, student, can sing and as well as dra
poet, student, can sing and as well as draw
poet, student, can sing and as well as drawi
poet, student, can sing and as well as drawin
o
oe
oet
oet,
oet, 
oet, s
oet, st
oet, stu
oet, stud
oet, stude
oet, studen
oet, student
oet, student,
oet, student, 
oet, student, c
oet, student, ca
oet, student, can
oet, student, can 
oet, student, can s
oet, student, can si
oet, student, can sin
oet, student, can sing
oet, student, can sing 
oet, student, can sing a
oet, student, can sing an
oet, student, can sing and
oet, student, can sing and 
oet, student, can sing and a
oet, student, can sing and as
oet, student, can sing and as 
oet, student, can sing and as w
oet, student, can sing and as we
oet, student, can sing and as wel
oet, student, can sing and as well
oet, student, can sing and as well 
oet, student, can sing and as well a
oet, student, can sing and as well as
oet, student, can sing and as well as 
oet, student, can sing and as well as d
oet, student, can sing and as well as dr
oet, student, can sing and as well as dra
oet, student, can sing and as well as draw
oet, student, can sing and as well as drawi
oet, student, can sing and as well as drawin
e
et
et,
et, 
et, s
et, st
et, stu
et, stud
et, stude
et, studen
et, student
et, student,
et, student, 
et, student, c
et, student, ca
et, student, can
et, student, can 
et, student, can s
et, student, can si
et, student, can sin
et, student, can sing
et, student, can sing 
et, student, can sing a
et, student, can sing an
et, student, can sing and
et, student, can sing and 
et, student, can sing and a
et, student, can sing and as
et, student, can sing and as 
et, student, can sing and as w
et, student, can sing and as we
et, student, can sing and as wel
et, student, can sing and as well
et, student, can sing and as well 
et, student, can sing and as well a
et, student, can sing and as well as
et, student, can sing and as well as 
et, student, can sing and as well as d
et, student, can sing and as well as dr
et, student, can sing and as well as dra
et, student, can sing and as well as draw
et, student, can sing and as well as drawi
et, student, can sing and as well as drawin
t
t,
t, 
t, s
t, st
t, stu
t, stud
t, stude
t, studen
t, student
t, student,
t, student, 
t, student, c
t, student, ca
t, student, can
t, student, can 
t, student, can s
t, student, can si
t, student, can sin
t, student, can sing
t, student, can sing 
t, student, can sing a
t, student, can sing an
t, student, can sing and
t, student, can sing and 
t, student, can sing and a
t, student, can sing and as
t, student, can sing and as 
t, student, can sing and as w
t, student, can sing and as we
t, student, can sing and as wel
t, student, can sing and as well
t, student, can sing and as well 
t, student, can sing and as well a
t, student, can sing and as well as
t, student, can sing and as well as 
t, student, can sing and as well as d
t, student, can sing and as well as dr
t, student, can sing and as well as dra
t, student, can sing and as well as draw
t, student, can sing and as well as drawi
t, student, can sing and as well as drawin
,
, 
, s
, st
, stu
, stud
, stude
, studen
, student
, student,
, student, 
, student, c
, student, ca
, student, can
, student, can 
, student, can s
, student, can si
, student, can sin
, student, can sing
, student, can sing 
, student, can sing a
, student, can sing an
, student, can sing and
, student, can sing and 
, student, can sing and a
, student, can sing and as
, student, can sing and as 
, student, can sing and as w
, student, can sing and as we
, student, can sing and as wel
, student, can sing and as well
, student, can sing and as well 
, student, can sing and as well a
, student, can sing and as well as
, student, can sing and as well as 
, student, can sing and as well as d
, student, can sing and as well as dr
, student, can sing and as well as dra
, student, can sing and as well as draw
, student, can sing and as well as drawi
, student, can sing and as well as drawin
 
 s
 st
 stu
 stud
 stude
 studen
 student
 student,
 student, 
 student, c
 student, ca
 student, can
 student, can 
 student, can s
 student, can si
 student, can sin
 student, can sing
 student, can sing 
 student, can sing a
 student, can sing an
 student, can sing and
 student, can sing and 
 student, can sing and a
 student, can sing and as
 student, can sing and as 
 student, can sing and as w
 student, can sing and as we
 student, can sing and as wel
 student, can sing and as well
 student, can sing and as well 
 student, can sing and as well a
 student, can sing and as well as
 student, can sing and as well as 
 student, can sing and as well as d
 student, can sing and as well as dr
 student, can sing and as well as dra
 student, can sing and as well as draw
 student, can sing and as well as drawi
 student, can sing and as well as drawin
s
st
stu
stud
stude
studen
student
student,
student, 
student, c
student, ca
student, can
student, can 
student, can s
student, can si
student, can sin
student, can sing
student, can sing 
student, can sing a
student, can sing an
student, can sing and
student, can sing and 
student, can sing and a
student, can sing and as
student, can sing and as 
student, can sing and as w
student, can sing and as we
student, can sing and as wel
student, can sing and as well
student, can sing and as well 
student, can sing and as well a
student, can sing and as well as
student, can sing and as well as 
student, can sing and as well as d
student, can sing and as well as dr
student, can sing and as well as dra
student, can sing and as well as draw
student, can sing and as well as drawi
student, can sing and as well as drawin
t
tu
tud
tude
tuden
tudent
tudent,
tudent, 
tudent, c
tudent, ca
tudent, can
tudent, can 
tudent, can s
tudent, can si
tudent, can sin
tudent, can sing
tudent, can sing 
tudent, can sing a
tudent, can sing an
tudent, can sing and
tudent, can sing and 
tudent, can sing and a
tudent, can sing and as
tudent, can sing and as 
tudent, can sing and as w
tudent, can sing and as we
tudent, can sing and as wel
tudent, can sing and as well
tudent, can sing and as well 
tudent, can sing and as well a
tudent, can sing and as well as
tudent, can sing and as well as 
tudent, can sing and as well as d
tudent, can sing and as well as dr
tudent, can sing and as well as dra
tudent, can sing and as well as draw
tudent, can sing and as well as drawi
tudent, can sing and as well as drawin
u
ud
ude
uden
udent
udent,
udent, 
udent, c
udent, ca
udent, can
udent, can 
udent, can s
udent, can si
udent, can sin
udent, can sing
udent, can sing 
udent, can sing a
udent, can sing an
udent, can sing and
udent, can sing and 
udent, can sing and a
udent, can sing and as
udent, can sing and as 
udent, can sing and as w
udent, can sing and as we
udent, can sing and as wel
udent, can sing and as well
udent, can sing and as well 
udent, can sing and as well a
udent, can sing and as well as
udent, can sing and as well as 
udent, can sing and as well as d
udent, can sing and as well as dr
udent, can sing and as well as dra
udent, can sing and as well as draw
udent, can sing and as well as drawi
udent, can sing and as well as drawin
d
de
den
dent
dent,
dent, 
dent, c
dent, ca
dent, can
dent, can 
dent, can s
dent, can si
dent, can sin
dent, can sing
dent, can sing 
dent, can sing a
dent, can sing an
dent, can sing and
dent, can sing and 
dent, can sing and a
dent, can sing and as
dent, can sing and as 
dent, can sing and as w
dent, can sing and as we
dent, can sing and as wel
dent, can sing and as well
dent, can sing and as well 
dent, can sing and as well a
dent, can sing and as well as
dent, can sing and as well as 
dent, can sing and as well as d
dent, can sing and as well as dr
dent, can sing and as well as dra
dent, can sing and as well as draw
dent, can sing and as well as drawi
dent, can sing and as well as drawin
e
en
ent
ent,
ent, 
ent, c
ent, ca
ent, can
ent, can 
ent, can s
ent, can si
ent, can sin
ent, can sing
ent, can sing 
ent, can sing a
ent, can sing an
ent, can sing and
ent, can sing and 
ent, can sing and a
ent, can sing and as
ent, can sing and as 
ent, can sing and as w
ent, can sing and as we
ent, can sing and as wel
ent, can sing and as well
ent, can sing and as well 
ent, can sing and as well a
ent, can sing and as well as
ent, can sing and as well as 
ent, can sing and as well as d
ent, can sing and as well as dr
ent, can sing and as well as dra
ent, can sing and as well as draw
ent, can sing and as well as drawi
ent, can sing and as well as drawin
n
nt
nt,
nt, 
nt, c
nt, ca
nt, can
nt, can 
nt, can s
nt, can si
nt, can sin
nt, can sing
nt, can sing 
nt, can sing a
nt, can sing an
nt, can sing and
nt, can sing and 
nt, can sing and a
nt, can sing and as
nt, can sing and as 
nt, can sing and as w
nt, can sing and as we
nt, can sing and as wel
nt, can sing and as well
nt, can sing and as well 
nt, can sing and as well a
nt, can sing and as well as
nt, can sing and as well as 
nt, can sing and as well as d
nt, can sing and as well as dr
nt, can sing and as well as dra
nt, can sing and as well as draw
nt, can sing and as well as drawi
nt, can sing and as well as drawin
t
t,
t, 
t, c
t, ca
t, can
t, can 
t, can s
t, can si
t, can sin
t, can sing
t, can sing 
t, can sing a
t, can sing an
t, can sing and
t, can sing and 
t, can sing and a
t, can sing and as
t, can sing and as 
t, can sing and as w
t, can sing and as we
t, can sing and as wel
t, can sing and as well
t, can sing and as well 
t, can sing and as well a
t, can sing and as well as
t, can sing and as well as 
t, can sing and as well as d
t, can sing and as well as dr
t, can sing and as well as dra
t, can sing and as well as draw
t, can sing and as well as drawi
t, can sing and as well as drawin
,
, 
, c
, ca
, can
, can 
, can s
, can si
, can sin
, can sing
, can sing 
, can sing a
, can sing an
, can sing and
, can sing and 
, can sing and a
, can sing and as
, can sing and as 
, can sing and as w
, can sing and as we
, can sing and as wel
, can sing and as well
, can sing and as well 
, can sing and as well a
, can sing and as well as
, can sing and as well as 
, can sing and as well as d
, can sing and as well as dr
, can sing and as well as dra
, can sing and as well as draw
, can sing and as well as drawi
, can sing and as well as drawin
 
 c
 ca
 can
 can 
 can s
 can si
 can sin
 can sing
 can sing 
 can sing a
 can sing an
 can sing and
 can sing and 
 can sing and a
 can sing and as
 can sing and as 
 can sing and as w
 can sing and as we
 can sing and as wel
 can sing and as well
 can sing and as well 
 can sing and as well a
 can sing and as well as
 can sing and as well as 
 can sing and as well as d
 can sing and as well as dr
 can sing and as well as dra
 can sing and as well as draw
 can sing and as well as drawi
 can sing and as well as drawin
c
ca
can
can 
can s
can si
can sin
can sing
can sing 
can sing a
can sing an
can sing and
can sing and 
can sing and a
can sing and as
can sing and as 
can sing and as w
can sing and as we
can sing and as wel
can sing and as well
can sing and as well 
can sing and as well a
can sing and as well as
can sing and as well as 
can sing and as well as d
can sing and as well as dr
can sing and as well as dra
can sing and as well as draw
can sing and as well as drawi
can sing and as well as drawin
a
an
an 
an s
an si
an sin
an sing
an sing 
an sing a
an sing an
an sing and
an sing and 
an sing and a
an sing and as
an sing and as 
an sing and as w
an sing and as we
an sing and as wel
an sing and as well
an sing and as well 
an sing and as well a
an sing and as well as
an sing and as well as 
an sing and as well as d
an sing and as well as dr
an sing and as well as dra
an sing and as well as draw
an sing and as well as drawi
an sing and as well as drawin
n
n 
n s
n si
n sin
n sing
n sing 
n sing a
n sing an
n sing and
n sing and 
n sing and a
n sing and as
n sing and as 
n sing and as w
n sing and as we
n sing and as wel
n sing and as well
n sing and as well 
n sing and as well a
n sing and as well as
n sing and as well as 
n sing and as well as d
n sing and as well as dr
n sing and as well as dra
n sing and as well as draw
n sing and as well as drawi
n sing and as well as drawin
 
 s
 si
 sin
 sing
 sing 
 sing a
 sing an
 sing and
 sing and 
 sing and a
 sing and as
 sing and as 
 sing and as w
 sing and as we
 sing and as wel
 sing and as well
 sing and as well 
 sing and as well a
 sing and as well as
 sing and as well as 
 sing and as well as d
 sing and as well as dr
 sing and as well as dra
 sing and as well as draw
 sing and as well as drawi
 sing and as well as drawin
s
si
sin
sing
sing 
sing a
sing an
sing and
sing and 
sing and a
sing and as
sing and as 
sing and as w
sing and as we
sing and as wel
sing and as well
sing and as well 
sing and as well a
sing and as well as
sing and as well as 
sing and as well as d
sing and as well as dr
sing and as well as dra
sing and as well as draw
sing and as well as drawi
sing and as well as drawin
i
in
ing
ing 
ing a
ing an
ing and
ing and 
ing and a
ing and as
ing and as 
ing and as w
ing and as we
ing and as wel
ing and as well
ing and as well 
ing and as well a
ing and as well as
ing and as well as 
ing and as well as d
ing and as well as dr
ing and as well as dra
ing and as well as draw
ing and as well as drawi
ing and as well as drawin
n
ng
ng 
ng a
ng an
ng and
ng and 
ng and a
ng and as
ng and as 
ng and as w
ng and as we
ng and as wel
ng and as well
ng and as well 
ng and as well a
ng and as well as
ng and as well as 
ng and as well as d
ng and as well as dr
ng and as well as dra
ng and as well as draw
ng and as well as drawi
ng and as well as drawin
g
g 
g a
g an
g and
g and 
g and a
g and as
g and as 
g and as w
g and as we
g and as wel
g and as well
g and as well 
g and as well a
g and as well as
g and as well as 
g and as well as d
g and as well as dr
g and as well as dra
g and as well as draw
g and as well as drawi
g and as well as drawin
 
 a
 an
 and
 and 
 and a
 and as
 and as 
 and as w
 and as we
 and as wel
 and as well
 and as well 
 and as well a
 and as well as
 and as well as 
 and as well as d
 and as well as dr
 and as well as dra
 and as well as draw
 and as well as drawi
 and as well as drawin
a
an
and
and 
and a
and as
and as 
and as w
and as we
and as wel
and as well
and as well 
and as well a
and as well as
and as well as 
and as well as d
and as well as dr
and as well as dra
and as well as draw
and as well as drawi
and as well as drawin
n
nd
nd 
nd a
nd as
nd as 
nd as w
nd as we
nd as wel
nd as well
nd as well 
nd as well a
nd as well as
nd as well as 
nd as well as d
nd as well as dr
nd as well as dra
nd as well as draw
nd as well as drawi
nd as well as drawin
d
d 
d a
d as
d as 
d as w
d as we
d as wel
d as well
d as well 
d as well a
d as well as
d as well as 
d as well as d
d as well as dr
d as well as dra
d as well as draw
d as well as drawi
d as well as drawin
 
 a
 as
 as 
 as w
 as we
 as wel
 as well
 as well 
 as well a
 as well as
 as well as 
 as well as d
 as well as dr
 as well as dra
 as well as draw
 as well as drawi
 as well as drawin
a
as
as 
as w
as we
as wel
as well
as well 
as well a
as well as
as well as 
as well as d
as well as dr
as well as dra
as well as draw
as well as drawi
as well as drawin
s
s 
s w
s we
s wel
s well
s well 
s well a
s well as
s well as 
s well as d
s well as dr
s well as dra
s well as draw
s well as drawi
s well as drawin
 
 w
 we
 wel
 well
 well 
 well a
 well as
 well as 
 well as d
 well as dr
 well as dra
 well as draw
 well as drawi
 well as drawin
w
we
wel
well
well 
well a
well as
well as 
well as d
well as dr
well as dra
well as draw
well as drawi
well as drawin
e
el
ell
ell 
ell a
ell as
ell as 
ell as d
ell as dr
ell as dra
ell as draw
ell as drawi
ell as drawin
l
ll
ll 
ll a
ll as
ll as 
ll as d
ll as dr
ll as dra
ll as draw
ll as drawi
ll as drawin
l
l 
l a
l as
l as 
l as d
l as dr
l as dra
l as draw
l as drawi
l as drawin
 
 a
 as
 as 
 as d
 as dr
 as dra
 as draw
 as drawi
 as drawin
a
as
as 
as d
as dr
as dra
as draw
as drawi
as drawin
s
s 
s d
s dr
s dra
s draw
s drawi
s drawin
 
 d
 dr
 dra
 draw
 drawi
 drawin
d
dr
dra
draw
drawi
drawin
r
ra
raw
rawi
rawin
a
aw
awi
awin
w
wi
win
i
in
n

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l3.py =============
Enter a string: ha haa haa 
All substrings are:
h
ha
ha 
ha h
ha ha
ha haa
ha haa 
ha haa h
ha haa ha
ha haa haa
a
a 
a h
a ha
a haa
a haa 
a haa h
a haa ha
a haa haa
 
 h
 ha
 haa
 haa 
 haa h
 haa ha
 haa haa
h
ha
haa
haa 
haa h
haa ha
haa haa
a
aa
aa 
aa h
aa ha
aa haa
a
a 
a h
a ha
a haa
 
 h
 ha
 haa
h
ha
haa
a
aa
a

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l3.py =============
Enter a string: yumm yummyyy
All substrings are:
y
yu
yum
yumm
yumm 
yumm y
yumm yu
yumm yum
yumm yumm
yumm yummy
yumm yummyy
u
um
umm
umm 
umm y
umm yu
umm yum
umm yumm
umm yummy
umm yummyy
m
mm
mm 
mm y
mm yu
mm yum
mm yumm
mm yummy
mm yummyy
m
m 
m y
m yu
m yum
m yumm
m yummy
m yummyy
 
 y
 yu
 yum
 yumm
 yummy
 yummyy
y
yu
yum
yumm
yummy
yummyy
u
um
umm
ummy
ummyy
m
mm
mmy
mmyy
m
my
myy
y
yy
y

============== RESTART: C:/Users/hp/OneDrive/Documents/p17l3.py =============
Enter a string: tarunima
All substrings are:
t
ta
tar
taru
tarun
taruni
tarunim
a
ar
aru
arun
aruni
arunim
r
ru
run
runi
runim
u
un
uni
unim
n
ni
nim
i
im
m

============== RESTART: C:/Users/hp/OneDrive/Documents/p18l3.py =============
Enter a string: kya hi likhu ab
Characters in alphabetical order: aabhhiikkluy

============== RESTART: C:/Users/hp/OneDrive/Documents/p19l3.py =============
Enter a string: meow meow gop gop gop
Most repeated word: gop
Frequency: 3

============== RESTART: C:/Users/hp/OneDrive/Documents/p20l3.py =============
Enter first string: ab kyaa likhu
Enter second string: kya likhu ab
The strings are not rotations.

============== RESTART: C:/Users/hp/OneDrive/Documents/p20l3.py =============
Enter first string: mtlb ab khtm
Enter second string: ab khtm mtlb
The strings are not rotations of each other.

============== RESTART: C:/Users/hp/OneDrive/Documents/p20l3.py =============
Enter first string: kyaahai
Enter second string: haikyaa
The strings are rotations of each other.

============== RESTART: C:/Users/hp/OneDrive/Documents/p21l3.py =============
Enter numbers separated by spaces: ab bda chhota kya ho
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p21l3.py", line 7, in <module>
    numbers[i] = int(numbers[i])
ValueError: invalid literal for int() with base 10: 'ab'

============== RESTART: C:/Users/hp/OneDrive/Documents/p21l3.py =============
Enter numbers separated by spaces: hello
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p21l3.py", line 7, in <module>
    numbers[i] = int(numbers[i])
ValueError: invalid literal for int() with base 10: 'hello'

============== RESTART: C:\Users\hp\OneDrive\Documents\p21l3.py =============
Enter numbers separated by spaces: 35
Largest element: 35
Smallest element: 35

============== RESTART: C:\Users\hp\OneDrive\Documents\p21l3.py =============
Enter numbers separated by spaces: 56 89 34
Largest element: 89
Smallest element: 34

============== RESTART: C:/Users/hp/OneDrive/Documents/p22l3.py =============
Enter numbers separated by spaces: 34 67 89 45 90 34 67 49
Ascending order: [34, 34, 45, 49, 67, 67, 89, 90]
Descending order: 90 89 67 67 49 45 34 34 

============== RESTART: C:/Users/hp/OneDrive/Documents/p23l3.py =============
Enter numbers separated by spaces: bk na bk ab
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/p23l3.py", line 6, in <module>
    numbers[i] = int(numbers[i])
ValueError: invalid literal for int() with base 10: 'bk'

============== RESTART: C:/Users/hp/OneDrive/Documents/p23l3.py =============
Enter numbers separated by spaces: 34 78 39 57 07 27 588
List after removing duplicates: [34, 78, 39, 57, 7, 27, 588]

============== RESTART: C:/Users/hp/OneDrive/Documents/p23l3.py =============
Enter numbers separated by spaces: 34 78 39 57 07 27 588 39 34
List after removing duplicates: [34, 78, 39, 57, 7, 27, 588]

============== RESTART: C:/Users/hp/OneDrive/Documents/p24l3.py =============
Enter numbers separated by spaces: 56 781 25 56 78 370 86
Reversed list: [86, 370, 78, 56, 25, 781, 56]

============== RESTART: C:/Users/hp/OneDrive/Documents/p25l3.py =============
Enter numbers separated by spaces: 36 78 37 70 27 858 -8
36 : 1
78 : 1
37 : 1
70 : 1
27 : 1
858 : 1
-8 : 1

============== RESTART: C:/Users/hp/OneDrive/Documents/p25l3.py =============
Enter numbers separated by spaces: 36 78 37 70 27 858 -8 36 27 858 -8
36 : 2
78 : 1
37 : 1
70 : 1
27 : 2
858 : 2
-8 : 2

============== RESTART: C:/Users/hp/OneDrive/Documents/p26l3.py =============
Enter elements of first list: assignment aur labsheet
Enter elements of second list: mn nhi lgta
First list: ['assignment', 'aur', 'labsheet']
Second list: ['mn', 'nhi', 'lgta']
Merged list: ['assignment', 'aur', 'labsheet', 'mn', 'nhi', 'lgta']
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p27l3.py =============
Enter numbers separated by spaces: 58 37 6 289 8970 368 279
Second largest number: 368
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p28l3.py =============
Enter elements of first list: python
Enter elements of second list: labsheet
Common elements: []
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p28l3.py =============
Enter elements of first list: tarunima
Enter elements of second list: taru
Common elements: []
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p28l3.py =============
Enter elements of first list: py world here
Enter elements of second list: py
Common elements: ['py']
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p29l3.py =============
Enter elements of first list: kuchu puchu
Enter elements of second list: kutta
Difference between the lists: ['kuchu', 'puchu']
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p29l3.py =============
Enter elements of first list: ht na gadhe
Enter elements of second list: gadhe
Difference between the lists: ['ht', 'na']
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p30l3.py =============
Enter numbers separated by spaces: 699 26 59 279 -69 -46 865
Even numbers: [26, -46]
Odd numbers: [699, 59, 279, -69, 865]
>>> 
============== RESTART: C:/Users/hp/OneDrive/Documents/p22l3.py =============
Enter numbers: 34 67 89 45 90 34 67 49
Ascending order: [34, 34, 45, 49, 67, 67, 89, 90]
Descending order: [90, 89, 67, 67, 49, 45, 34, 34]
