# Q11: Check whether two strings are anagrams

str1 = input("Enter first string: ")
str2 = input("Enter second string: ")

# Remove spaces
s1 = ""
s2 = ""

for ch in str1:
    if ch != ' ':
        s1 = s1 + ch.lower()

for ch in str2:
    if ch != ' ':
        s2 = s2 + ch.lower()

if len(s1) != len(s2):
    print("The strings are not anagrams.")
else:
    anagram = True

    for ch in s1:
        count1 = 0
        count2 = 0

        for c in s1:
            if c == ch:
                count1 += 1

        for c in s2:
            if c == ch:
                count2 += 1

        if count1 != count2:
            anagram = False
            break

    if anagram:
        print("The strings are anagrams.")
    else:
        print("The strings are not anagrams.")
