# Q18: Sort characters of a string alphabetically

text = input("Enter a string: ")

characters = []

# Store characters in a list
for ch in text:
    if ch != ' ':
        characters.append(ch)

# Bubble sort
for i in range(len(characters)):
    for j in range(0, len(characters) - i - 1):

        if characters[j] > characters[j + 1]:
            temp = characters[j]
            characters[j] = characters[j + 1]
            characters[j + 1] = temp

result = ""

for ch in characters:
    result = result + ch

print("Characters in alphabetical order:", result)
